// Grade Book.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include <string>
#include <fstream>
#include "mainMenu.h"
#include "Semester.h"
#include "Student.h"
#include "StudentLinkedList.h"
using namespace std;


//void StudentLinkedList(string Name, string lastName);


int main()
{
	string menuOption;
	char studentOption;
	string studentName;
	string studentLastName;
	int studentNumber;
	char newSemesterOption;

	cout << "***********************************" << endl;
	cout << "Instructors Grade Book" << endl;
	cout << "***********************************" << endl;
	cout << "Is this a new semester?" << endl;
	cout << "(Y/N): ";
	cin >> newSemesterOption;

	StudentLinkedList *listStudents = new StudentLinkedList();

	//toupper(newSemesterOption);
	if (toupper(newSemesterOption) == 'Y' || 'YES')
	{
		//Initialize the file to an Empty state

		Semester newSemester;
		newSemester.setUpSemestre();

		cout << "Would you like to add a Student now?" << endl;
		cin >> studentOption;

		

		if (studentOption == 'Y')
		{
			//Calls the Student Class to create a new student
			Student newStudent;
			newStudent.setStudent();

			studentName = newStudent.getStudentName();
			studentLastName = newStudent.getStudentLastName();
			studentNumber = newStudent.getStudentNumber();


//			StudentLinkedList *listStudents = new StudentLinkedList();
			listStudents->addStudentInformation(studentName, studentLastName);
			listStudents->addStudentNumber(studentNumber);
			
			
			//Ask to the user if it wants to continue adding students
			do
			{
				cout << "Would you like to add another Student? (Y/N)" << endl;
				cin >> studentOption;
				//If user does not want to add more student at the
				//moment this will change the variable to exit the loop
				if (studentOption == 'Y')
				{
					newStudent.setStudent();

					studentName = newStudent.getStudentName();
					studentLastName = newStudent.getStudentLastName();
					studentNumber = newStudent.getStudentNumber();

					listStudents->addStudentInformation(studentName, studentLastName);
					listStudents->addStudentNumber(studentNumber);

				}
				else if (studentOption == 'N')
				{
					studentOption = 'Q';
				}
				else
				{
					cout << "Please enter Y to adD a Student or N to continue" << endl;
					cin >> studentOption;
				}
				

			} while (studentOption != 'Q');

		}
		else
		{

		}


	}
	else
	{
		//Load file information
	}
	
	listStudents->print();

	//Displays the menu and gets the option selected.
	mainMenu MenuOption;
	menuOption = MenuOption.getMenueOption();

	//Run the Menu Loop until the user wants to exit the program.
	do
	{

	} while (menuOption != "Q");


	system("cls");
	system("PAUSE");
	
}



