#include "stdafx.h"
#include "Semester.h"
#include <iostream>
#include <string>
using namespace std;


Semester::Semester()
{
}

void Semester::setUpSemestre()
{
	//Define the semester content
	cout << "How many programming assignments(range 0-6)?" << endl;
	cin >> numPrograms;
	cout << "What is the relative weight of the programs? " << endl;
	cin >> weightPercentProgram;
	cout << "How many numbers of tests(range 0-4)?" << endl;
	cin >> numTests;
	cout << "What is the relative weight of the tests? " << endl;
	cin >> weightPercentTests;
	cout << "Will there be final exams(If yes enter 1 if not enter 0)?" << endl;
	cin >> numFinalExams;
	cout << "What is the relative weight of the final exam? " << endl;
	cin >> weightPercentFinalExams;

	setNumPrograms(numPrograms);
	setNumTest(numTests);
	setFinalExam(numFinalExams);
	setNumTest(numTests);
	setNumPrograms(numPrograms);
	setFinalExam(numFinalExams);


	getNumTest();
	getNumPrograms();
	getFinalExam();
	getWeightTest();
	getWeightPrograms();
	getWeightFinalExam();

}

int Semester::getNumTest() const
{
	return numTests;
}

int Semester::getNumPrograms() const
{
	return numPrograms;
}

int Semester::getFinalExam() const
{
	return numFinalExams;
}

int Semester::getWeightTest() const
{
	return numTests;
}

int Semester::getWeightPrograms() const
{
	return numPrograms;
}

int Semester::getWeightFinalExam() const
{
	return numFinalExams;
}

void Semester::setNumTest(int newNumTest)
{
	numTests = newNumTest;
}

void Semester::setNumPrograms(int newNumProgram)
{
	numPrograms = newNumProgram;
}

void Semester::setFinalExam(int newNumFinalExam)
{
	numFinalExams = newNumFinalExam;
}

void Semester::setWeightTest(int newWeightPercentTests)
{
	weightPercentTests = newWeightPercentTests;
}

void Semester::setWeightPrograms(int newWeightPercentProgram)
{
	weightPercentProgram = newWeightPercentProgram;
}

void Semester::setWeightFinalExam(int newWeightPercentFinalExams)
{
	weightPercentFinalExams = newWeightPercentFinalExams;
}

void Semester::printSemester()
{
}

Semester::~Semester()
{
}
