#pragma once
#include <iostream>
#include <string>
using namespace std;

class Semester
{
private:
	int numPrograms;
	int weightPercentProgram;
	int numTests;
	int weightPercentTests;
	int numFinalExams;
	int weightPercentFinalExams;

public:
	Semester();

	void setUpSemestre();

	int getNumTest() const;
	int getNumPrograms() const;
	int getFinalExam()const;

	int getWeightTest() const;
	int getWeightPrograms() const;
	int getWeightFinalExam()const;

	void setNumTest(int);
	void setNumPrograms(int);
	void setFinalExam(int);

	void setWeightTest(int);
	void setWeightPrograms(int);
	void setWeightFinalExam(int);

	void printSemester();

	~Semester();
};

