#include "stdafx.h"
#include "Student.h"
#include<iostream>
#include <string>
using namespace std;


Student::Student()
{
}

void Student::setStudent()
{
	cout << "Enter the Student Last Name:" << endl;
	cin >> lastName;
	cout << "Enter the Student First Name: "<< endl;
	cin >> firstName;
	cout << "What is the student number(1-9999)" << endl;
	cin >> studentNumber;

	setStudentName(firstName);
	setStudentLastName(lastName);
	setStudentNumber(studentNumber);

	getStudentName();
	getStudentLastName();
	getStudentNumber();
}

string Student::getStudentName() const
{
	return string(firstName);
}

string Student::getStudentLastName() const
{
	return string(lastName);
}

int Student::getStudentNumber() const
{
	return studentNumber;
}

void Student::setStudentName(string newStudentName)
{
	firstName = newStudentName;
}

void Student::setStudentLastName(string newStudentLastName)
{
	lastName = newStudentLastName;
}

void Student::setStudentNumber(int newStudentNumber)
{
	studentNumber = newStudentNumber;
}


Student::~Student()
{
	//delete this;
}
