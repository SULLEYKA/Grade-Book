#pragma once
#include<iostream>
#include <string>
using namespace std;

class Student
{
private:
	string lastName;
	string firstName;
	int studentNumber;

public:
	Student();
	void setStudent();

	string getStudentName() const;
	string getStudentLastName() const;
	int getStudentNumber() const;

	void setStudentName(string);
	void setStudentLastName(string);
	void setStudentNumber(int);

	~Student();
};

