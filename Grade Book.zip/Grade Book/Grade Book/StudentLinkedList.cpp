#include "stdafx.h"
#include "StudentLinkedList.h"


StudentLinkedList::StudentLinkedList()
{
}

void StudentLinkedList::addStudentInformation(string Name, string lastName)
{
	nodeStudent *node = new nodeStudent();
	node->newStudent = Name + " " +lastName;
	this->count++;

	if (head == NULL)
	{
		head = node;
		tail = node;
		tail->next = NULL;
	}
	else
	{
		tail->next = node;
		tail = node;
		node->next = NULL;
	}
}

void StudentLinkedList::addStudentNumber(int newNumber)
{
	nodeStudentNumber *node = new nodeStudentNumber();
	node->newStudentNumber = newNumber;

	if (headNum == NULL)
	{
		headNum = node;
		tailNum = node;
		tail->next = NULL;
	}
	else
	{
		tailNum->next = node;
		tailNum = node;
		node->next = NULL;
	}
}

void StudentLinkedList::print()
{
	nodeStudent *iterator = new nodeStudent();
	nodeStudentNumber *iteratorNum = new nodeStudentNumber();
	iterator = head;
	iteratorNum = headNum;
	int count = 1;
	while (iterator != NULL && iteratorNum != NULL)
	{
		cout << count << " ." << iterator->newStudent <<  "  " << iteratorNum->newStudentNumber << endl;
		iterator = iterator->next;
		count++;
	}
	cout << "Total of student for this Semester: " << this->count << endl;
}


void StudentLinkedList::removeStudentName()
{
	nodeStudent *iterator = head; //Star from the beginning
	while (iterator->next != NULL)
	{
		iterator = iterator->next; //This wiil land it on tail
	}
	delete this->tail;
	this->tail = iterator;
	this->tail->next = NULL;
	this - count--;
}


StudentLinkedList::~StudentLinkedList()
{
	delete this;
}
