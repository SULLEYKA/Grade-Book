#pragma once
#include <string>
#include <iostream>
using namespace std;

struct nodeStudent {
	string newStudent;
	nodeStudent *next;
};

struct nodeStudentNumber {
	int newStudentNumber;
	nodeStudentNumber *next;
};

class StudentLinkedList
{
private:
	int count;
	nodeStudent *head;
	nodeStudent *tail;

	nodeStudentNumber *headNum;
	nodeStudentNumber *tailNum;

public:
	StudentLinkedList();

	void addStudentInformation(string, string);
	void addStudentNumber(int);
	void print();

	void removeStudentName();

	~StudentLinkedList();
};

