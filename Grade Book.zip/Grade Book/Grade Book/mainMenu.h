#pragma once
#include <iostream>
using namespace std;

class mainMenu
{
private:

	string menuOption;
	string mainMenuOption;

public:

	mainMenu();
	string getMenueOption() const;
	void setMenuOption(string);
	~mainMenu();
};

